1. About

ReCube is device which was constructed after many hours of Cube3 firmware reverse engineering. It is done with usage of Arduino Nano v3, so if you like to have it, you need to buy one. Current folder conatins:

Avrdude			- folder with avrdude for arduino flashing
ReCubeSchematic	- schematic picture of V2 version (Arduino Nano)
ReCubeV1board	- new firmware for old board schamtic (data pin is connected to D13) 
program.bat		- batch file for Arduino flashing
ReCubeLight.ino.hex	- hex line for flashing via arduino usb connection
ReCubeLight.ino.with_bootloader.hex - hex file for flashing with usage ISP 

2. One-click usage

There is possibility of quick full cartridge "charging" with jus one-click. To use it connect ReCube to USB port in your computer or any other USB power supply, put Recube pins on cartridge and click push button. GREEN LED means that you have 100% charged cartridge, RED one - something was wrong (probably pins do not connect correctly memory). 

3. Command line

Comport the same as Arduino device, speed: 115200

Use serial console (via TeraTerm or Putty) to program cartridge:

Available commands
0;                 - This command list
1;                 - Check cartridge type
                       0: Cube3
                       1: Ekocycle
                       2: Cube Pro
2,<bank number>;   - Get bank data
3;                 - Get max amount
4;                 - Get material type
                       0 = PLA
                       1 = ABS
                       2 = NYLON
                       3 = EKO
                       5 = WUD
                       6 = FLX
                       7 = MET
For Cube Pro:	
                       8 = PET

5;                 - Get color type
                       0:White          | 1:Silver    | 2:Black              | 3:Brown
                       4:Tan            | 5:NeonGreen | 6:GlowInTheDarkGreen | 7:Green
                       8:Teal           | 9:Blue      | 10:GlowInTheDarkBlue | 11:Purple
                       12:Magenta       | 13:Red      | 14:Orange            | 15:Yellow
                       16:DarkGrey      | 17:Coral    | 18:ForestGreen       | 19:PaleYellow
                       20:NavyBlue      | 21:Gold     | 22:Bronze            | 23:Natural
                       24:InfinityRinse | 25:Wood     | 26:Fire              | 27:Snow
                       28:Water         | 29:Blush    | 30:Marsala           | 31:Midnight
                       32:Sapphire      | 33:Concrete | 34:Copper            | 35:Grey
For Cube Pro:
                       36:IndustrialGrey| 37:Grass    | 38:Sun

6;                 - Get Memory ID
7;                 - Get Current Amount in %
8,<current amount in %>; - Set Current Amount 0-100

For Cube Pro:
9,<max amount>;    - Set Max amount for CubePRO typical 254302

Others:
9,<max amount>;    - Set Max amount for Cube3 typical 106680

10,<material>,<color>;    - Set Cartridge material and color type
11,<printer>;    - Set cartridge printer type
                       0: Cube3
                       1: Ekocycle
                       2: Cube Pro

Options as described in menu, remember that command are requested after ";" not "ENTER"

In Light version available are:

- Get max amount
- Get material type
- Get color type
- Get current amount in %
- Set current amount in %

All answers for requests are like below:

<requestNR>,<errorNumber>,<value>;

ie:

Request: 2;

Answer: 2,4,4026625024;

This is wrong answer 4 means no devicer. Below example of proper answer:

Answer: 2,0,106680; 

Error types in hex (given output in terminal is decimal):

		OK			= 0x00,
		ENABLE      = 0x02,
		DISABLE     = 0x03,
		NODEVICE    = 0x04,      //No device on 1 wire bus.
		IDCRC8ER    = 0x05,      //CRC8 error on ROMID
		CRC16ER     = 0x06,      //CRC16 error
		OUTRAN      = 0x07,      //Range error in DS2411.
		FCER        = 0x08,      //Family code error.
		LESS        = 0x09,      //A < B.
		BIG         = 0x0A,      //A > B.
		EQ          = 0x0B,      //A = B.
		WRSCC16ER   = 0x0C,      //Write scratch pad CRC16 error.
		RDSCC16ER   = 0x0D,      //Read scratch pad CRC16 error.
		PGER        = 0x0E,	  //Page error used in 1 wire EEPROM.
		SPGER       = 0x0F,      //Subpage error used in 1 wire EEPROM.
		BYTER       = 0x10,      //Too many bytes to be read.
		COPYOK      = 0x11,      //Copy scrachpad Ok.
		COPYER      = 0x12,      //Copy scrachpad error.
		WRERR       = 0x13,      //Write memory error.
		STPER       = 0x14,      //Writing position error.
		FILBER      = 0x15,      //Too many bytes to be writen to a subpage.
		RDEEER      = 0x16,      //Read EEPROM error.
		P3PRO       = 0x17,      //Page3 read protected.
		RWSCER      = 0x18,      //Read Write scratch error.
		SETSEER     = 0x19,      //Set secret error.
		LOADER      = 0x20,      //Load secret error.
		RWEEP       = 0x21,      //Indicating rewriting EEPROM.
		WRONG       = 0x22

4. Flashing

Program could be flashed via avrdude. Please use command as described below:

avrdude -C avrdude.conf -v -patmega328p -carduino -PCOM3 -b57600 -D "-Uflash:w:../ReCubeLight.ino.hex:i"

-PCOM3 - could be different in your case

OR use program.bat file, but setup correct arduino com port inside bat file.

5. Donation 

If my work is helpful and interesting for you, please do not forget to Donate ;)

https://www.paypal.me/tomuro

6. Version PRO

Light version offer you fill maximum possible value with just one click or set any percentage you like. Pro version offers additional setttings like: material type, material color, increase or decrease maximum material amount in cartridge. If you would like to have PRO version contact via tomuro@haxtom.com.